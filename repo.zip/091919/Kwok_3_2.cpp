/*********************************************************
* file name: Kwok_3_2.cpp
* programmer name: Jack Kwok
* date created: 9/19/19
* date of last revision: 9/19/19
* details of the revision: none
* short description:  this program asks the user how many
tickets for each class of seats were sold, then displays
the amount of income generated from ticket sales.
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	//Program description
	cout << "This program will display\n"
		<< "the amount of income generated from ticket sales.\n\n";

	// Declaring the variables: types and names
	const double costA = 15, costB = 12, costC = 9;
	int classA, classB, classC;
	double income;

	// Variable initialization: getting the input from the user
	cout << "How many tickets in Class A seats were sold?\n";
	cin >> classA;
	cout << "How many tickets in Class B seats were sold?\n";
	cin >> classB;
	cout << "How many tickets in Class C seats were sold?\n";
	cin >> classC;

	// Calculations
	income = classA * costA + classB * costB + classC * costC;

	// Display the results
	cout << fixed << setprecision(2) << "Income: $" << income << endl;

	system("pause");
	return 0;
}

/*
This program will display
the amount of income generated from ticket sales.

How many tickets in Class A seats were sold?
12
How many tickets in Class B seats were sold?
4
How many tickets in Class C seats were sold?
33
Income: $525.00
Press any key to continue . . .
*/

/*
This program will display
the amount of income generated from ticket sales.

How many tickets in Class A seats were sold?
49
How many tickets in Class B seats were sold?
80
How many tickets in Class C seats were sold?
3
Income: $1722.00
Press any key to continue . . .

*/