/*********************************************************
* file name: Kwok_3_23.cpp
* programmer name: Jack Kwok
* date created: 9/19/19
* date of last revision: 9/19/19
* details of the revision: none
* short description:  this program will display the amount
	-of money Joe paid for the stock
	-of commision Joe paid his broker when he bought the stock
	-that Joe sold the stock for
	-of commission Joe paid his broker when he sold the stock
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	//Program description
	cout << "This program will display\n"
		<< "information about Joe's stock transactions\n\n";

	// Declaring the variables: types and names
	const int sharesBought = 1000, sharesSold = 1000;
	const double buyPricePerShare = 45.50, sellPricePerShare = 56.90;
	double buyStockTotal, sellStockTotal, buyingCommission, sellingCommission;
	double profit;

	// Calculations
	buyStockTotal = sharesBought * buyPricePerShare;
	buyingCommission = buyStockTotal * 0.02;
	sellStockTotal = sharesSold * sellPricePerShare;
	sellingCommission = sellStockTotal * 0.02;
	profit = sellStockTotal - buyStockTotal - buyingCommission - sellingCommission;

	// Display the results
	cout << fixed << setprecision(2);
	cout << "Joe paid $" << buyStockTotal <<
		" for the stock in Acme Software Inc. last month and paid his broker $"
		<< buyingCommission << " when he bought it.\nHe sold his stock for $" 
		<< sellStockTotal << " and paid his broker $" << sellingCommission 
		<< " when he sold the stock.\nJoe made $" << profit 
		<< " after selling his stock and paying the 2 commissions to his broker" 
		<< endl;


	system("pause");
	return 0;
}

/*
This program will display
information about Joe's stock transactions

Joe paid $45500.00 for the stock in Acme Software Inc. last month and paid his broker $910.00 when he bought it.
He sold his stock for $56900.00 and paid his broker $1138.00 when he sold the stock.
Joe made $9352.00 after selling his stock and paying the 2 commissions to his broker
Press any key to continue . . .

*/