#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
	int x = 0;
	while (x < 5)
	{
		cout << x << endl;
		x++;
	}
	return 0;
}
