/*********************************************************
* file name: Kwok_4_13.cpp
* programmer name: Jack Kwok
* date created: 9/26/19
* date of last revision: 9/26/19
* details of the revision: none
* short description: This program will ask the user to input the number of books the user has purchased this month
*then displays the number of points awarded
**********************************************************/
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and display" << endl
		<< "the number of points awarded to the user based on the number of books the user inputs\n\n";
	// Declaring the variables: types and names
	int books, points;
	// Variable initialization: getting the input from the user
	cout << "Enter the number of books purchased this month: ";
	cin >> books;
	// Calculations
	if (books == 0)
		points = 0;
	else if (books == 1)
		points = 5;
	else if (books == 2)
		points = 15;
	else if (books == 3)
		points = 30;
	else if (books > 3)
		points = 60;
	// Display the results
	cout << "Points: " << points << endl;

	return 0;
}

/*
This program will calculate and display
the number of points awarded to the user based on the number of books the user inputs

Enter the number of books purchased this month: 5
Points: 60
*/

/*
This program will calculate and display
the number of points awarded to the user based on the number of books the user inputs

Enter the number of books purchased this month: 3
Points: 30
*/

/*
This program will calculate and display
the number of points awarded to the user based on the number of books the user inputs

Enter the number of books purchased this month: 0
Points: 0
*/