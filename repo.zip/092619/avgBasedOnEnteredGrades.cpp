#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	double exam, total, avg;
	int count, numGrades;
	char letterGrade;

	count = 0;

	cout << "Number of grades: ";
	cin >> numGrades;

	while (count < numGrades) {
		cout << "Exam grade: ";
		cin >> exam;
		total += exam;
		count++;
	}
	avg = total / (count + 1);
	cout << "Average: " << avg << endl;
	if (avg >= 90)
		letterGrade = 'A';
	else if (avg >= 80)
		letterGrade = 'B';
	else if (avg >= 70)
		letterGrade = 'C';
	else if (avg >= 60)
		letterGrade = 'D';
	else
		letterGrade = 'F';
	cout << "Letter Grade: " << letterGrade << endl;
		return 0;
}