/*********************************************************
* file name: Kwok_8_6.cpp
* programmer name: Jack Kwok
* date created: 11/29/19
* date of last revision: 11/29/19
* details of the revision: none
* short description:  using a selection sort to sort an array of strings
**********************************************************/
#include <iostream>
#include <string>
using namespace std;

void selectionSort(string[], int);
void printArray(const string[], int);

int main() {
	cout << "This Program will use a selection sort to sort an array of strings.\n\n";
	const int NUM_NAMES = 20;
	string names[NUM_NAMES] = { "Collins, Bill", "Smith, Bart", "Allet, Jim",
						   "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
						   "Taylor, Terri", "Johnson, Jill",
						   "Aliison, Jeff", "Weaver, Jim", "Pore, Bob",
						   "Rutherford, Greg", "Javens, Renee",
						   "Harrison, Rose", "Setzer, Cathy",
						   "Pike, Gordon", "Holland, Beth" };
	cout << "The unsorted values are\n";
	printArray(names, NUM_NAMES);
	//sort
	selectionSort(names, NUM_NAMES);
	//print sorted list
	cout << "The sorted values are\n";
	printArray(names, NUM_NAMES);

	return 0;
}

void selectionSort(string array[], int NUM_NAMES)
{
	int startScan, minIndex;
	string minValue;

	for (startScan = 0; startScan < (NUM_NAMES - 1); startScan++)
	{
		minIndex = startScan;
		minValue = array[startScan];
		for (int index = startScan + 1; index < NUM_NAMES; index++)
		{
			if (array[index] < minValue)
			{
				minValue = array[index];
				minIndex = index;
			}
		}
		array[minIndex] = array[startScan];
		array[startScan] = minValue;
	}
}

void printArray(const string arr[], int NUM_NAMES) {
	for (int i = 0; i < NUM_NAMES; i++) {
		cout << "[" << arr[i] << "] ";
	}
	cout << "\n";
}
/*
This Program will use a selection sort to sort an array of strings.

The unsorted values are
[Collins, Bill] [Smith, Bart] [Allet, Jim] [Griffin, Jim] [Stamey, Marty] [Rose, Geri] [Taylor, Terri] [Johnson, Jill] [Aliison, Jeff] [Weaver, Jim] [Pore, Bob] [Rutherford, Greg] [Javens, Renee] [Harrison, Rose] [Setzer, Cathy] [Pike, Gordon] [Holland, Beth] [] [] []
The sorted values are
[] [] [] [Aliison, Jeff] [Allet, Jim] [Collins, Bill] [Griffin, Jim] [Harrison, Rose] [Holland, Beth] [Javens, Renee] [Johnson, Jill] [Pike, Gordon] [Pore, Bob] [Rose, Geri] [Rutherford, Greg] [Setzer, Cathy] [Smith, Bart] [Stamey, Marty] [Taylor, Terri] [Weaver, Jim]

C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\112919\Debug\112919.exe (process 69752) exited with code 0.
Press any key to close this window . . .
*/