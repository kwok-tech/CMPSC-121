/*********************************************************
* file name: Kwok_8_7.cpp
* programmer name: Jack Kwok
* date created: 11/29/19
* date of last revision: 11/29/19
* details of the revision: none
* short description:  using a binary search to find a string in an array of strings
**********************************************************/
#include <iostream>
#include <string> 
using namespace std;

// Function prototype
void sortArray(string[], int);
int binarySearch(string[], int, string);
const int SIZE = 20;

int main()
{
	cout << "This program demontrates the use of a binary search\n\n";
	const int NUM_NAMES = 20;
	string names[NUM_NAMES] = { "Collins, Bill", "Smith, Bart", "Allen, Jim",
							   "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
							   "Taylor, Terri", "Johnson, Jill", "Allison, Jeff",
							   "Looney, Joe", "Wolfe, Bill", "James, Jean",
							   "Weaver, Jim", "Pore, Bob", "Rutherford, Greg",
							   "Javens, Renee", "Harrison, Rose", "Setzer, Cathy",
							   "Pike, Gordon", "Holland, Beth" };

	// Variables 
	string empName;
	int results;
	//sort first
	sortArray(names, NUM_NAMES);
	//input
	cout << "Please enter an employee's name: ";
	getline(cin, empName);
	//search
	results = binarySearch(names, NUM_NAMES, empName);
	//result
	if (results == -1)
		cout << "That name does not exist in the array.\n";
	else
	{
		// Otherwise results contains the subscript of
		// the specified employee ID in the array.
		cout << "That name is found at element " << results;
		cout << " in the array.\n";
	}
	return 0;
}

void sortArray(string names[], int size)
{
	int startScan, minIndex;
	string minValue;

	for (startScan = 0; startScan < (size - 1); startScan++)
	{
		minIndex = startScan;
		minValue = names[startScan];
		for (int index = startScan + 1; index < size; index++)
		{
			if (names[index] < minValue)
			{
				minValue = names[index];
				minIndex = index;
			}
		}
		names[minIndex] = names[startScan];
		names[startScan] = minValue;
	}
}

int binarySearch(string names[], int size, string value)
{
	int first = 0,             // First array element
		last = size - 1,       // Last array element
		middle,                // Mid point of search
		position = -1;         // Position of search value
	bool found = false;        // Flag

	while (!found && first <= last)
	{
		middle = (first + last) / 2;     // Calculate mid point
		if (names[middle] == value)      // If value is found at mid
		{
			found = true;
			position = middle;
		}
		else if (names[middle] > value)  // If value is in lower half
			last = middle - 1;
		else
			first = middle + 1;           // If value is in upper half
	}
	return position;
}

/*
This program demontrates the use of a binary search

Please enter an employee's name: Collins, Bill
That name is found at element 2 in the array.

C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\112919\Debug\112919.exe (process 48232) exited with code 0.
Press any key to close this window . . .
*/

/*This program demontrates the use of a binary search

Please enter an employee's name: kwok, jack
That name does not exist in the array.

C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\112919\Debug\112919.exe (process 62116) exited with code 0.
Press any key to close this window . . .

*/
/*
This program demontrates the use of a binary search

Please enter an employee's name: Pore, Bob
That name is found at element 11 in the array.

C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\112919\Debug\112919.exe (process 92908) exited with code 0.
Press any key to close this window . . .
*/