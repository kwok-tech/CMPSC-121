/*********************************************************
* file name: Kwok_7_4.cpp
* programmer name: Jack Kwok
* date created: 11/08/19
* date of last revision: 11/08/19
* details of the revision: none
* short description:  This program will calculate and display
all numbers in an array that a greater than the number 'n'
**********************************************************/

#include <iostream>
using namespace std;

void numsGreater(int[], int, int);

int main() {
	// Program description
	cout << "This program will calculate and display\n"
		<< "all numbers in an array that a greater than the number 'n'\n\n";
	// Declaring the variables: types and names
	const int ARRSIZE=10;
	int arr[ARRSIZE];
	int n;
	// Variable initialization: getting the input from the user
	cout << "Enter an array of ints of size 10\n";
	for (int i = 0; i < ARRSIZE; i++) {
		cout << i << ": ";
		cin >> arr[i];
	}
	cout << "Enter n: ";
	cin >> n;
	// Calculations
	// Display the results
	numsGreater(arr, ARRSIZE, n);
	
	return 0;
}

void numsGreater(int a[], int size, int n) {
	int count = 0;
	for (int i = 0; i < size; i++) {
		if (a[i] > n) {
			cout << a[i] << " ";
			count++;
		}
	}
	if (count == 0)
		cout << "n is greater or equal to than everything.";
}

/*
This program will calculate and display
all numbers in an array that a greater than the number 'n'

Enter an array of ints of size 10
0: 20
1: 67
2: 8
3: 1
4: -90
5: 70
6: 30
7: 9
8: 8
9: 4
Enter n: 10
20 67 70 30
C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\110819\Debug\110819.exe (process 70120) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
all numbers in an array that a greater than the number 'n'

Enter an array of ints of size 10
0: 10
1: 69
2: 89
3: 7
4: 79
5: 76767
6: 6786
7: 8
8: 90
9: 7
Enter n: 6
10 69 89 7 79 76767 6786 8 90 7
C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\110819\Debug\110819.exe (process 31820) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
all numbers in an array that a greater than the number 'n'

Enter an array of ints of size 10
0: 10
1: 10
2: 10
3: 10
4: 10
5: 10
6: 10
7: 10
8: 10
9: 10
Enter n: 10
n is greater or equal to than everything.
C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\110819\Debug\110819.exe (process 84232) exited with code 0.
Press any key to close this window . . .

*/