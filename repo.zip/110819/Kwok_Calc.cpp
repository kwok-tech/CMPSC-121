/*********************************************************
* file name: Kwok_Calc.cpp
* programmer name: Jack Kwok
* date created: 11/08/19
* date of last revision: 11/08/19
* details of the revision: none
* short description:  This program will model a simple calculator
**********************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
using namespace std;

void scan_data(char&, float&);
void do_next_op(char, float, float&);

int main() {
	// Program description
	cout << "This program will model a simple calculator\n" << endl;
	// Declaring the variables: types and names
	float val =0,tempVal;
	char op;
	// Variable initialization: getting the input from the user
	cout << "The starting value is 0. Enter a vaild operator and value."
		<< "\nThe vaild operators are:"
		<< "\n+\tadd"
		<< "\n-\tsubtract"
		<< "\n*\tmultiply"
		<< "\n/\tdivide"
		<< "\n^\tpower"
		<< "\nq\tquit\n";
	scan_data(op, tempVal);
	while (op != 'q') {
		// Calculations
		do_next_op(op, tempVal, val);
		scan_data(op, tempVal);
	}
	cout << "final result is " << val;

	return 0;
}

void scan_data(char& c, float& f) {
	cin >> c >> f;
	if (c != '+' && c != '-' && c != '*' && c != '/' && c != '^' && c != 'q') {
		cout << "Invalid operation.";
		exit(1);
	}
}

void do_next_op(char c, float change, float& nVal) {
	if (c == '+')
		nVal += change;
	else if (c == '-')
		nVal -= change;
	else if (c == '*')
		nVal *= change;
	else if (c == '/')
		nVal /= change;
	else if (c == '^')
		nVal = pow(nVal, change);
	// Display the results
	cout << "result so far is " << nVal << endl;
}

/*
This program will model a simple calculator

The starting value is 0. Enter a vaild operator and value.
The vaild operators are:
+       add
-       subtract
*       multiply
/       divide
^       power
q       quit
p 8
Invalid operation.
C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\110819\Debug\110819.exe (process 24148) exited with code 1.
Press any key to close this window . . .

*/

/*
This program will model a simple calculator

The starting value is 0. Enter a vaild operator and value.
The vaild operators are:
+       add
-       subtract
*       multiply
/       divide
^       power
q       quit
+ 10.8
result so far is 10.8
-0.8
result so far is 10
* 7
result so far is 70
/ 3.5
result so far is 20
^ 2.0
result so far is 400
q 0
final result is 400
C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\110819\Debug\110819.exe (process 80560) exited with code 0.
Press any key to close this window . . .

*/