/*********************************************************
* file name: Kwok_5_18.cpp
* programmer name: Jack Kwok
* date created: 10/17/19
* date of last revision: 10/17/19
* details of the revision: none
* short description: This program will calculate and output 
into another text file a bar chart showing the population growth
**********************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and output into a text file" << endl
		<< "a bar chart showing the population growth.\n\n";
	// Declaring the variables: types and names
	const int NUMYEARS = 6, ONEASTERISK = 1000;
	ofstream outFile;
	ifstream inFile;
	string fileName;
	int year, population, count = 0, numOfAsterisks;
	
	// Variable initialization : getting the input from the user
	year = 1900;
	cout << "Enter name of input file: ";
	cin >> fileName;
	inFile.open(fileName);
	if (inFile.fail()) {
		cout << "Can't find file";
		exit(1);
	}
	outFile.open("output.txt");
	outFile << "PRAIRIEVILLE POPULATION GROWTH\n(each * represents 1, 000 people)";
	// Calculations
		for (int i = 0; i <NUMYEARS; i++) {
			inFile >> population;
			numOfAsterisks = population / ONEASTERISK;
			outFile << "\n" <<  year << " ";
			for (int j = 0; j < numOfAsterisks; j++)
				outFile << "*";
			year += 20;
		}
	return 0;
}