/*********************************************************
* file name: Kwok_7_19.cpp
* programmer name: Jack Kwok
* date created: 11/15/19
* date of last revision: 11/15/19
* details of the revision: none
* short description:  This program will create a two-dimensional integer
					array initialized with test data.
**********************************************************/

#include <iostream>
using namespace std;

const int ROWSIZE = 3;
const int COLSIZE = 4;
int getTotal(int arr[ROWSIZE][COLSIZE]);
double getAverage(int arr[ROWSIZE][COLSIZE]);
int getRowTotal(int arr[ROWSIZE][COLSIZE], int);
int getColumnTotal(int arr[ROWSIZE][COLSIZE], int);
int getHighestInRow(int arr[ROWSIZE][COLSIZE], int);
int getLowestInRow(int arr[ROWSIZE][COLSIZE], int);

int main() {
	// Program description
	cout << "This program will create a"
		<< " two-dimensional integer array initialized with test data.\n\n";
	// Declaring the variables: types and names
	int total, rowNum;
	double avg;
	// Variable initialization: getting the input from the user
	int arr[ROWSIZE][COLSIZE] = {
		{50,1,7,4},
		{13,9,68,-7},
		{56,3,7,60},
	};
	//Calculations
	total = getTotal(arr);
	avg = getAverage(arr);
	//print array
	for (int i = 0; i < ROWSIZE; i++) {
		for (int j = 0; j < COLSIZE; j++) {
			cout << arr[i][j] << "\t";
		}
		cout << endl;
	}
	//Output
	cout << "The total of this 2-Dimensional Array is " << total
		<< "\nThe average of this 2-Dimensional Array is " << avg;
	//row totals
	for (int i = 0; i < ROWSIZE; i++) {
		cout << "\nRow " << i << " Total: " << getRowTotal(arr, i);
	}
	//column totals
	for (int i = 0; i < COLSIZE; i++) {
		cout << "\nColumn " << i << " Total: " << getColumnTotal(arr, i);
	}
	//highest and lowest in row
	cout << "\nWhich row do you want to check? ";
	cin >> rowNum;
	if (!(rowNum >= 0) || !(rowNum < ROWSIZE)) {
		cout << "Invaild Input.";
		exit(1);
	}
	cout << "\nThe highest number in Row " << rowNum << " is " << getHighestInRow(arr, rowNum);
	cout << "\nThe lowest number in Row " << rowNum << " is " << getLowestInRow(arr, rowNum);
	return 0;
}

int getTotal(int arr[ROWSIZE][COLSIZE]) {
	int t = 0;
	for (int i = 0; i < ROWSIZE; i++) {
		for (int j = 0; j < COLSIZE; j++) {
			t += arr[i][j];
		}
	}
	return t;
}

double getAverage(int arr[ROWSIZE][COLSIZE]) {
	return (getTotal(arr) / (double)(ROWSIZE * COLSIZE));
}

int getRowTotal(int arr[ROWSIZE][COLSIZE], int row) {
	int rT = 0;
	for (int j = 0; j < COLSIZE; j++) {
		rT += arr[row][j];
	}
	return rT;
}

int getColumnTotal(int arr[ROWSIZE][COLSIZE], int col) {
	int cT = 0;
	for (int i = 0; i < ROWSIZE; i++) {
		cT += arr[i][col];
	}
	return cT;
}

int getHighestInRow(int arr[ROWSIZE][COLSIZE], int row) {
	int biggest = arr[row][0];
	for (int j = 1; j < COLSIZE; j++) {
		if (arr[row][j] > biggest)
			biggest = arr[row][j];
	}
	return biggest;
}

int getLowestInRow(int arr[ROWSIZE][COLSIZE], int row) {
	int lowest = arr[row][0];
	for (int j = 1; j < COLSIZE; j++) {
		if (arr[row][j] < lowest)
			lowest = arr[row][j];
	}
	return lowest;
}

/*
This program will create a two-dimensional integer array initialized with test data.

50      1       7       4
13      9       68      -7
56      3       7       60
The total of this 2-Dimensional Array is 271
The average of this 2-Dimensional Array is 22.5833
Row 0 Total: 62
Row 1 Total: 83
Row 2 Total: 126
Column 0 Total: 119
Column 1 Total: 13
Column 2 Total: 82
Column 3 Total: 57
Which row do you want to check? 1

The highest number in Row 1 is 68
The lowest number in Row 1 is -7
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 79160) exited with code 0.
Press any key to close this window . . .
*/
/*
This program will create a two-dimensional integer array initialized with test data.

50      1       7       4
13      9       68      -7
56      3       7       60
The total of this 2-Dimensional Array is 271
The average of this 2-Dimensional Array is 22.5833
Row 0 Total: 62
Row 1 Total: 83
Row 2 Total: 126
Column 0 Total: 119
Column 1 Total: 13
Column 2 Total: 82
Column 3 Total: 57
Which row do you want to check? 9
Invaild Input.
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 27564) exited with code 1.
Press any key to close this window . . .
*/
/*
This program will create a two-dimensional integer array initialized with test data.

50      1       7       4
13      9       68      -7
56      3       7       60
The total of this 2-Dimensional Array is 271
The average of this 2-Dimensional Array is 22.5833
Row 0 Total: 62
Row 1 Total: 83
Row 2 Total: 126
Column 0 Total: 119
Column 1 Total: 13
Column 2 Total: 82
Column 3 Total: 57
Which row do you want to check? -1
Invaild Input.
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 22916) exited with code 1.
Press any key to close this window . . .
*/
/*
This program will create a two-dimensional integer array initialized with test data.

50      1       7       4
13      9       68      -7
56      3       7       60
The total of this 2-Dimensional Array is 271
The average of this 2-Dimensional Array is 22.5833
Row 0 Total: 62
Row 1 Total: 83
Row 2 Total: 126
Column 0 Total: 119
Column 1 Total: 13
Column 2 Total: 82
Column 3 Total: 57
Which row do you want to check? 0

The highest number in Row 0 is 50
The lowest number in Row 0 is 1
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 79936) exited with code 0.
Press any key to close this window . . .
*/
/*
This program will create a two-dimensional integer array initialized with test data.

50      1       7       4
13      9       68      -7
56      3       7       60
The total of this 2-Dimensional Array is 271
The average of this 2-Dimensional Array is 22.5833
Row 0 Total: 62
Row 1 Total: 83
Row 2 Total: 126
Column 0 Total: 119
Column 1 Total: 13
Column 2 Total: 82
Column 3 Total: 57
Which row do you want to check? 2

The highest number in Row 2 is 60
The lowest number in Row 2 is 3
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 13232) exited with code 0.
Press any key to close this window . . .
*/