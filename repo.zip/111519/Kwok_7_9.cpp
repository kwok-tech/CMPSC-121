/*********************************************************
* file name: Kwok_7_9.cpp
* programmer name: Jack Kwok
* date created: 11/15/19
* date of last revision: 11/15/19
* details of the revision: none
* short description:  This program will calculate and display a worker's payroll
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

const int NUMOFEMPLOYEES = 7;
void storeEmployInfo(long int[], int[], double[]);
void calcWages(int[], double[], double[]);

int main() {
	// Program description
	cout << "This program will calculate and display"
		<< " a worker's payroll\n\n";
	// Declaring the variables: types and names
	long int empId[NUMOFEMPLOYEES] = { 
			5658845,
			4520125,
			7895122,
			8777541,
			8451277,
			1302850,
			7580489 };
	int hours[NUMOFEMPLOYEES];
	double payRate[NUMOFEMPLOYEES];
	double wages[NUMOFEMPLOYEES];
	// Variable initialization: getting the input from the user
	storeEmployInfo(empId, hours, payRate);
	//Calculations
	calcWages(hours, payRate, wages);
	//output
	for (int i = 0; i < NUMOFEMPLOYEES; i++) {
		cout << "\nEmployee ID#: " << empId[i]
			<< "\nWage: $" << fixed << setprecision(2) << wages[i];
	}

	return 0;
}

void storeEmployInfo(long int id[], int hrs[], double pay[]) {
	for (int i = 0; i < NUMOFEMPLOYEES; i++) {
		cout << "\nEmployee ID#: " << id[i]
			<< "\nHours Worked: ";
		cin >> hrs[i];
		while (hrs[i] < 0) {
			cout << "Positive Values only: ";
			cin >> hrs[i];
		}
		cout << "\nPay Rate: $";
		cin >> pay[i];
		while (pay[i] < 15) {
			cout << "Minimum is $15: $";
			cin >> pay[i];
		}
	}
}

void calcWages(int hrs[], double pay[], double wages[]) {
	for (int i = 0; i < NUMOFEMPLOYEES; i++) {
		wages[i] = hrs[i] * pay[i];
	}
}

/*
This program will calculate and display a worker's payroll


Employee ID#: 5658845
Hours Worked: 0

Pay Rate: $6
Minimum is $15: $7
Minimum is $15: $30

Employee ID#: 4520125
Hours Worked: 7

Pay Rate: $16

Employee ID#: 7895122
Hours Worked: 2

Pay Rate: $400

Employee ID#: 8777541
Hours Worked: -8
Positive Values only: 9

Pay Rate: $15

Employee ID#: 8451277
Hours Worked: 27

Pay Rate: $1
Minimum is $15: $45

Employee ID#: 1302850
Hours Worked: 12

Pay Rate: $12
Minimum is $15: $15

Employee ID#: 7580489
Hours Worked: 2

Pay Rate: $60

Employee ID#: 5658845
Wage: $0.00
Employee ID#: 4520125
Wage: $112.00
Employee ID#: 7895122
Wage: $800.00
Employee ID#: 8777541
Wage: $135.00
Employee ID#: 8451277
Wage: $1215.00
Employee ID#: 1302850
Wage: $180.00
Employee ID#: 7580489
Wage: $120.00
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 27428) exited with code 0.
Press any key to close this window . . .
*/
/*
This program will calculate and display a worker's payroll


Employee ID#: 5658845
Hours Worked: 43

Pay Rate: $43

Employee ID#: 4520125
Hours Worked: 23

Pay Rate: $2
Minimum is $15: $31

Employee ID#: 7895122
Hours Worked: 3

Pay Rate: $1
Minimum is $15: $3
Minimum is $15: $1
Minimum is $15: $36

Employee ID#: 8777541
Hours Worked: 565

Pay Rate: $
2
Minimum is $15: $42

Employee ID#: 8451277
Hours Worked: 5

Pay Rate: $34

Employee ID#: 1302850
Hours Worked: 2

Pay Rate: $18.85

Employee ID#: 7580489
Hours Worked: 5

Pay Rate: $70.25

Employee ID#: 5658845
Wage: $1849.00
Employee ID#: 4520125
Wage: $713.00
Employee ID#: 7895122
Wage: $108.00
Employee ID#: 8777541
Wage: $23730.00
Employee ID#: 8451277
Wage: $170.00
Employee ID#: 1302850
Wage: $37.70
Employee ID#: 7580489
Wage: $351.25
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 85252) exited with code 0.
Press any key to close this window . . .
*/
/*
This program will calculate and display a worker's payroll


Employee ID#: 5658845
Hours Worked: 15

Pay Rate: $15

Employee ID#: 4520125
Hours Worked: 15

Pay Rate: $15

Employee ID#: 7895122
Hours Worked: 15

Pay Rate: $15

Employee ID#: 8777541
Hours Worked: 15

Pay Rate: $15

Employee ID#: 8451277
Hours Worked: 15

Pay Rate: $15

Employee ID#: 1302850
Hours Worked: 15

Pay Rate: $15

Employee ID#: 7580489
Hours Worked: 15

Pay Rate: $15

Employee ID#: 5658845
Wage: $225.00
Employee ID#: 4520125
Wage: $225.00
Employee ID#: 7895122
Wage: $225.00
Employee ID#: 8777541
Wage: $225.00
Employee ID#: 8451277
Wage: $225.00
Employee ID#: 1302850
Wage: $225.00
Employee ID#: 7580489
Wage: $225.00
C:\Users\kwokj\source\repos\111519\Debug\111519.exe (process 78168) exited with code 0.
Press any key to close this window . . .
*/