/*********************************************************
* file name: Kwok_4_18.cpp
* programmer name: Jack Kwok
* date created: 10/04/19
* date of last revision: 10/04/19
* details of the revision: none
* short description:  This program calculates and displays the percentage of calories
**********************************************************/

#include <iostream>
using namespace std;

int main()
{
	// Program description
	cout << "This program will calculate and display the percentage of calories that come from fat" << endl;

	// Declaring the variables: types and names
	double  fat, calories, percentage_calories, calories_fat;

	// Variable initialization: getting the input from the user
	cout << "\nEnter the number of calories in the food: ";
	cin >> calories;

	while (calories < 0) {
		cout << "Enter a value greater than 0: ";
		cin >> calories;
	}

	cout << "\nEnter number of fat grams in the food: ";
	cin >> fat;


	while (fat < 0) {
		cout << "Enter a value greater than 0: ";
		cin >> fat;
	}

	calories_fat = fat * 9;
	percentage_calories = (calories_fat / calories) * 100;

	if (calories_fat <= 30) {
		cout << "Low in fat" << endl;
		cout << "Percentage of calories: " << percentage_calories << "%" << endl;
	}
	else if (calories_fat > calories) {
		cout << "Either the fat gram or the total calories were entered incorrectly";
	}
	else {
		cout << "Percentage of calories: " << percentage_calories << "%" << endl;
	}   
	// Calculations
	calories_fat = fat * 9;
	percentage_calories = calories_fat / calories;

	return 0;
}

/*
This program will calculate and display the percentage of calories that come from fat

Enter the number of calories in the food: 9

Enter number of fat grams in the food: 2
Low in fat
Percentage of calories: 200%
*/

/*
This program will calculate and display the percentage of calories that come from fat

Enter the number of calories in the food: 7

Enter number of fat grams in the food: 8
Either the fat gram or the total calories were entered incorrectly
*/

/*
This program will calculate and display the percentage of calories that come from fat

Enter the number of calories in the food: -9
Enter a value greater than 0: -8
Enter a value greater than 0: 7

Enter number of fat grams in the food: -1
Enter a value greater than 0: 7
Either the fat gram or the total calories were entered incorrectly
*/