/*********************************************************
* file name: Kwok_4_13.cpp
* programmer name: Jack Kwok
* date created: 10/4/19
* date of last revision: 10/4/19
* details of the revision: none
* short description:  Calculating and displaying the number of books and the points awarded
**********************************************************/

#include <iostream>
using namespace std;

int main()
{
	// Program description
	cout << "This program will calculate and display\n"
		<< "the number of books purchased and the points awarded for the purchase\n";

	// Declaring the variables: types and names
	int books, points;

	// Variable initialization: getting the input from the user
	cout << "The amount of books purchased: ";
	cin >> books;

	if (books < 0) {
		cout << "Invalid number" << endl;
	}
	else {
		switch (books) {
		case 0:
			points = 0;
			break;
		case 1:
			points = 5;
			break;
		case 2:
			points = 15;
			break;
		case 3:
			points = 30;
			break;
		default:
			points = 60;
			break;
		}
		cout << "Points: " << points << endl;

	}
	return 0;
}

/*
This program will calculate and display
the number of books purchased and the points awarded for the purchase
The amount of books purchased: 0
Points: 0
*/

/*
This program will calculate and display
the number of books purchased and the points awarded for the purchase
The amount of books purchased: 2
Points: 15
*/

/*
This program will calculate and display
the number of books purchased and the points awarded for the purchase
The amount of books purchased: 9
Points: 60
*/