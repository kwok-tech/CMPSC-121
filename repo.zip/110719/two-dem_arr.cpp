#include <iostream>
#include <iomanip>
using namespace std;

const int MAX = 3;

int main() {
	string studentInfo[MAX][MAX+1];
	//input
	for (int i = 0; i < MAX; i++) {
		cout << "Enter Student " << i + 1 << "'s Last Name: ";
		cin >> studentInfo[i][0];
		cout << "\nEnter Student " << i + 1 << "'s Grades: \n";
		for (int j = 0; j < MAX; j++) {

		}
	}
}