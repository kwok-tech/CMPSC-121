/********************************************************************************************
                      Week 11:  In-Class Exercise Template

Write a C++ program that reads a list of grades from the file grades.txt and appends the
appropriate letter grade for each student to the same data file.

Reading, writing and assigning letter grade should be performed by
appropriate functions (minimum of two functions needed).

For letter grade use the criteria that was used in class, e.g. =90 is an A, etc.

Hints:
A file can be opened for input and appended output at the same time.
When reading from a file the header line should be read outside the loop.
End of the file has been identified by "zzzzz"

********************************************************************************************/


#include <iostream>
#include <string>
#include <fstream>
using namespace std;

const int MAX_SIZE = 4;
// Function prototypes
void instructions();
void writeFile(ofstream& outFile,
               string firstName[],
               string lastName[],
               char letterGrade[]);
void readFile(ifstream& inFile,
              string firstName[],
              string lastName[],
              float average[]);
float calcAverage(float exam1, float exam2, float exam3, float exam4);
char getLetterGrade(float average);

int main()
{
	// Program description
	instructions();  // function call

	// Declare the variables
	ifstream inFile;
	ofstream outFile;

	string firstName[MAX_SIZE],
           input,
		   lastName[MAX_SIZE];

	float average[MAX_SIZE];
	char letterGrade[MAX_SIZE];

    // Open the file for reading & check for failure

	inFile.open("newGrades.txt");
	if (inFile.fail())
	{
		cout << "Unable to open file for input\n";
		exit(1);
	}

    // Open the file for writing in append mode & check for failure

	outFile.open("newGrades.txt", ios::app);
	if (outFile.fail())
	{
		cout << "Unable to open file for output\n";
		exit(1);
	}

    // Throw out the header
    //getline(inFile,input);
    outFile << endl;

    // Main calculation
        // Call readFile() to read remainder of the line
		readFile(inFile, firstName, lastName, average);

        //Populate the letterGrade array - Calculate the letter grade
		// Need a loop that calls the function and populate the letterGrade array
		for (int i = 0; i < MAX_SIZE; i++)
		{
			letterGrade[i] = getLetterGrade(average[i]);
		}
		inFile.close();
        // Write to the file by calling writeFile()
		writeFile(outFile, firstName, lastName, letterGrade);

    // close files
    
    outFile.close();
	system("pause");
    return(0);
}

// Function implementations
void instructions()
{
    // Add more to the cout statement below
    cout << "This program will calculate the averages of the grades listed in newGrades.txt\n\n";
}

void writeFile(ofstream& outFile,
	string firstName[],
	string lastName[],
	char letterGrade[])
{
	cout << "In writeFile\n";
    // write data to file  -- like cout (need a loop)
	for (int i = 0; i < MAX_SIZE; i++)
	{
		outFile << firstName[i] << " " << lastName[i] << "\t" << letterGrade[i] << endl;
//		cout << firstName[i] << " " << lastName[i] << "\t" << letterGrade[i] << endl;
	}
	
}

void readFile(ifstream& inFile,
	string firstName[],
	string lastName[],
	float average[])   // used to store average for each student
{
    // read all lines  -- like cin
	int i = 0;
	float exam1, exam2, exam3, exam4;
	while (i < MAX_SIZE && inFile >> firstName[i] && firstName[i] != "zzzzz")   //firstName is read here
	{
		// read remainder of the record - row
		inFile >> lastName[i] >> exam1 >> exam2 >> exam3 >> exam4;
		// add code to process contents of file.
		average[i] = calcAverage(exam1, exam2, exam3, exam4);
		i++;
	}
}

float calcAverage(float exam1, float exam2, float exam3, float exam4)
{
	return (exam1 + exam2 + exam3 + exam4) / MAX_SIZE;

}

char getLetterGrade(float average)
{
	char letterGrade = ' ';
	if (average >= 90)
		letterGrade = 'A';
	else if (average >= 80)
		letterGrade = 'B';
	else if (average >= 70)
		letterGrade = 'C';
	else if (average >= 60)
		letterGrade = 'D';
	else
		letterGrade = 'F';
	return letterGrade;
}

