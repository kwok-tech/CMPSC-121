/*********************************************************
* file name: Kwok_6_14.cpp
* programmer name: Jack Kwok
* date created: 10/25/19
* date of last revision: 10/25/19
* details of the revision: none
* short description:  This program will calculate and display the status of an order.
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int readyToShip(int, int);
void printData(int , int , double);

int main() {
	// Program description
	cout << "This program will calculate and display" << endl
		<< "  status of an order.\n\n";
	// Declaring the variables: types and names
	int spoolsOrdered, spoolStock;
	char yon;
	double shipOrHand;
	// Variable initialization: getting the input from the user
	cout << "The number of spools ordered: ";
	cin >> spoolsOrdered;
	if (spoolsOrdered < 1) {
		cout << "Invaild Input";
		exit(1);
	}
	cout << "\nThe number of spools in stock: ";
	cin >> spoolStock;
	if (spoolStock < 0) {
		cout << "Invaild Input";
		exit(2);
	}
	cout << "\nAre there special shipping and handling charges? (Y/N)";
	cin >> yon;
	while (yon != 'Y' && yon != 'y' && yon != 'N' && yon != 'n') {
		cout << "Invaild Answer. (Y/N)";
		cin >> yon;
	}
	if (yon == 'Y' || yon == 'y') {
		cout << "Special charges per spool: ";
		cin >> shipOrHand;
		while (shipOrHand < 0) {
			cout << "Must be positive number.";
			cin >> shipOrHand;
		}

	} else {
		shipOrHand = 10.00;
	}
	
	// Display the results
	cout << fixed << setprecision(2);
	printData(spoolsOrdered, spoolStock, shipOrHand);

	return 0;
}

int readyToShip(int ordered, int stock) {
	if (stock >= ordered)
		return ordered;
	else
		return stock;
}
void printData(int ordered, int stock, double sh) {
	cout << "\nNumber of spools ready to ship from current stock: ";
	cout << readyToShip(ordered,stock);
	cout << "\nNumber of spools on backorder: ";
	if (ordered > stock)
		cout << ordered - stock;
	cout << "\nSubtotal of the portion ready to ship: $" 
		<< readyToShip(ordered, stock) * 100;
	cout << "\nTotal Shipping and handling charges: $"
		<< sh * readyToShip(ordered, stock);
	cout << "\nTotal of the order ready to ship: $"
		<< (sh * readyToShip(ordered, stock))+ 100.00 * readyToShip(ordered, stock);

}

/*
This program will calculate and display
  status of an order.

The number of spools ordered: 100

The number of spools in stock: 99

Are there special shipping and handling charges? (Y/N)n

Number of spools ready to ship from current stock: 99
Number of spools on backorder: 1
Subtotal of the portion ready to ship: $9900
Total Shipping and handling charges: $990.00
Total of the order ready to ship: $10890.00
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 50048) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
  status of an order.

The number of spools ordered: 3

The number of spools in stock: 0

Are there special shipping and handling charges? (Y/N)o
Invaild Answer. (Y/N)u
Invaild Answer. (Y/N)N

Number of spools ready to ship from current stock: 0
Number of spools on backorder: 3
Subtotal of the portion ready to ship: $0
Total Shipping and handling charges: $0.00
Total of the order ready to ship: $0.00
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 93080) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
  status of an order.

The number of spools ordered: 0
Invaild Input
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 33548) exited with code 1.
Press any key to close this window . . .

*/

/*
This program will calculate and display
  status of an order.

The number of spools ordered: 9

The number of spools in stock: -1
Invaild Input
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 31884) exited with code 2.
Press any key to close this window . . .

*/

/*
This program will calculate and display
  status of an order.

The number of spools ordered: 60

The number of spools in stock: 9

Are there special shipping and handling charges? (Y/N)y
Special charges per spool: 100

Number of spools ready to ship from current stock: 9
Number of spools on backorder: 51
Subtotal of the portion ready to ship: $900
Total Shipping and handling charges: $900.00
Total of the order ready to ship: $1800.00
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 91468) exited with code 0.
Press any key to close this window . . .

*/