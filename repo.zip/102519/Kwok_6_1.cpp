/*********************************************************
* file name: Kwok_6_1.cpp
* programmer name: Jack Kwok
* date created: 10/25/19
* date of last revision: 10/25/19
* details of the revision: none
* short description:  This program will calculate and display the retail price using user data inputs
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

double calculateRetail(double, double);

int main() {
	// Program description
	cout << "This program will calculate and display" <<endl
		<< " the retail price using user data inputs\n\n";
	// Declaring the variables: types and names
	double cost, markup, retail;
	// Variable initialization: getting the input from the user
	cout << "Wholesale Cost: $";
	cin >> cost;
	if (cost < 0) {
		cout << "Cost can't be negative.";
		exit(1);
	}
	cout << "\nMarkup Percentage: ";
	cin >> markup;
	if (markup < 0 || markup > 100) {
		cout << "Invaild Input";
		exit(2);
	}
	// Calculations
	retail = calculateRetail(cost, markup);
	// Display the results
	cout << fixed << setprecision(2);
	cout << "Retail Price: $" << retail;

	return 0;
}
double calculateRetail(double c, double m) {
	return c * (1 + (m / 100));
}
/*
This program will calculate and display
 the retail price using user data inputs

Wholesale Cost: $5.00

Markup Percentage: 100
Retail Price: $10.00
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 14184) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
 the retail price using user data inputs

Wholesale Cost: $3.00

Markup Percentage: 110
Invaild Input
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 82656) exited with code 2.
Press any key to close this window . . .
*/

/*
This program will calculate and display
 the retail price using user data inputs

Wholesale Cost: $-9
Cost can't be negative.
C:\Users\kwokj\source\repos\102519\Debug\102519.exe (process 3388) exited with code 1.
Press any key to close this window . . .

*/