/*********************************************************
* file name: Kwok_11_13.cpp
* programmer name: Jack Kwok
* date created: 12/06/19
* date of last revision: 12/06/19
* details of the revision: none
* short description: This program will simulate a soft drink machine
**********************************************************/
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <fstream>
using namespace std;

struct Drinks {
	string name;
	double cost;
	int numOfDrinks;
};
const int SIZE = 5;
double earned = 0.00;

void kbInitialize(Drinks[]);
void fileInitialize(ifstream&, Drinks[]);
void displayDrinks(Drinks[]);
void userPick(Drinks[]);
void sort(Drinks[]);

int main() {
	// Program description
	cout << "This program will simulate a soft drink machine\n\n";
	// Declaring the variables: types and names
	int input;
	Drinks machines[SIZE];
	ofstream outFile;
	ifstream inFile;
	// Variable initialization: getting the input from the user
	// open file for input
	inFile.open("DrinkMachine.txt");
	if (inFile.fail())
	{
		cout << "Unable to open file for input\n";
		exit(2);
	}
	// open file for output
	outFile.open("DrinkMachine.txt", ios::app);
	if (outFile.fail())
	{
		cout << "Unable to open file for output\n";
		exit(1);
	}
	//menu
	cout << "Menu \n1. Initialize the machine via the keyboard"
		<< "\n2. Initialize the machine via a file"
		<< "\n3. Display the list of drinks, including cost and number available"
		<< "\n4. Let the user pick a drink"
		<< "\n5. Sorts the structure array by quantity of each drink in the machine."
		<< "\n0. END";
	cin >> input;
	while (input != 0) {
		// Calculations
		if (input == 1) {
			kbInitialize(machines);
		}
		else if (input == 2) {
			fileInitialize(inFile, machines);
		}
		else if (input == 3) {
			displayDrinks(machines);
		}
		else if (input == 4) {
			userPick(machines);
		}
		else if (input == 5) {
			sort(machines);
		}
		else {
			cout << "Invaild input.\n";
		}
		//menu
		cout << "Menu \n1. Initialize the machine via the keyboard"
			<< "\n2. Initialize the machine via a file"
			<< "\n3. Display the list of drinks, including cost and number available"
			<< "\n4. Let the user pick a drink"
			<< "\n5. Sorts the structure array by quantity of each drink in the machine."
			<< "\n0. END";
		cin >> input;
	}
	// Display the results
	cout << "strut data in in the file.";
	inFile.close();
	outFile.close();

	return 0;
}

void kbInitialize(Drinks m[]) {
	for (int i = 0; i < SIZE; i++) {
		cout << "Drink " << i << "'s Name: ";
		getline(cin, m[i].name);
		cout << "Drink " << i << "'s Cost";
		cin >> m[i].cost;
		cout << "Number of " << m[i].name;
		cin >> m[i].numOfDrinks;
	}
}
void fileInitialize(ifstream& infile, Drinks m[]) {
	string title;
	getline(infile, title);
	for (int i = 0; i < SIZE; i++) {
		infile >> m[i].name >> m[i].cost >> m[i].numOfDrinks;
	}
}
void displayDrinks(Drinks m[]) {
	for (int i = 0; i < SIZE; i++) {
		cout << "\nDrink Name: " << m[i].name;
		cout << "\nDrink Cost" << m[i].cost;
		cout << "\nNumber of Drinks: " << m[i].numOfDrinks;
	}
}
void userPick(Drinks m[]) {
	string drink;
	double spent;
	int index = -1;
	cout << "Select a drink: ";
	cin >> drink;
	for (int i = 0; i < SIZE; i++) {
		if (drink == m[i].name) {
			if (m[i].numOfDrinks != 0)
				index = i;
			else
				cout << "SOLD OUT";
		}
	}
	while (index == -1) {
		cout << "Invalid drink selection, Select a drink: ";
		for (int i = 0; i < SIZE; i++) {
			if (drink == m[i].name) {
				if (m[i].numOfDrinks != 0)
					index = i;
				else
					cout << "SOLD OUT";
			}
		}
	}
	cout << "Amount inserted into machine: $";
	cin >> spent;
	while (spent < m[index].cost) {
		cout << "Not enough, Amount inserted into machine: $";
		cin >> spent;
	}
	cout << "Amount of change: " << (spent - m[index].cost);
	earned += m[index].cost;
	m[index].numOfDrinks = m[index].numOfDrinks - 1;
}
void sort(Drinks m[]) {
	
}