/*********************************************************
* file name: Kwok_10_12.cpp
* programmer name: Jack Kwok
* date created: 12/06/19
* date of last revision: 12/06/19
* details of the revision: none
* short description:
**********************************************************/

#include <iostream>
#include <string>
#include <string.h>
using namespace std;

bool checkLen(int);
bool checkUpcase(string, int);
bool checkLowercase(string, int);
bool checkNum(string, int);

int main() {
	// Program description
	cout << "This program will ask the user for a password and verifies of it meets the criteria.\n" << endl;
	// Declaring the variables: types and names
	string password;
	int size;
	// Variable initialization: getting the input from the user
	cout << "----PASSWORD VERIFIER PROGRAM----\n\n";
	cout << "Enter a password that meets the following criteria:\n"
		<< "-Minimum of 6 characters in length.\n"
		<< "-Contains at least one uppercase and one lowercase letter.\n"
		<< "-Contains at least one digit.\n\n";
	cout << "->";
	cin >> password;
	size = password.length();
	// Calculations
	while (!(checkLen(size) && checkUpcase(password, size) && checkLowercase(password, size) && checkNum(password, size))) {
		if (!checkLen(size))
			cout << "Error, password must be at least 6 characters long.\n";

		if (!checkUpcase(password, size))
			cout << "Error, password must contain at least one upper case letter.\n";

		if (!checkLowercase(password, size))
			cout << "Error, password must contain at least one lower case letter.\n";

		if (!checkNum(password, size))
			cout << "Error, password must contain at least one digit.\n";
		cout << "Please re-enter password: ";
		cin >> password;
		size = password.length();
	}
	// Display the results
	cout << "\nYou entered a valid password.\n\n";

	return 0;
}


bool checkLen(int size) {
	return (size >= 6);
}

bool checkUpcase(string pass, int size) {
	for (int i = 0; i < size; i++) {
		if (isupper(pass[i]))
			return true;
	}
	return false;
}

bool checkLowercase(string pass, int size) {
	for (int i = 0; i < size; i++) {
		if (islower(pass[i]))
			return true;
	}
	return false;
}

bool checkNum(string pass, int size) {
	for (int i = 0; i < size; i++) {
		if (isdigit(pass[i]))
			return true;
	}
	return false;
}

/*
This program will ask the user for a password and verifies of it meets the criteria.

----PASSWORD VERIFIER PROGRAM----

Enter a password that meets the following criteria:
-Minimum of 6 characters in length.
-Contains at least one uppercase and one lowercase letter.
-Contains at least one digit.

->p
Error, password must be at least 6 characters long.
Error, password must contain at least one upper case letter.
Error, password must contain at least one digit.
Please re-enter password: Pass
Error, password must be at least 6 characters long.
Error, password must contain at least one digit.
Please re-enter password: Password
Error, password must contain at least one digit.
Please re-enter password: Password123

You entered a valid password.


C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\120619\Debug\120619.exe (process 94868) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will ask the user for a password and verifies of it meets the criteria.

----PASSWORD VERIFIER PROGRAM----

Enter a password that meets the following criteria:
-Minimum of 6 characters in length.
-Contains at least one uppercase and one lowercase letter.
-Contains at least one digit.

->oifdjjgfl
Error, password must contain at least one upper case letter.
Error, password must contain at least one digit.
Please re-enter password: jAck
Error, password must be at least 6 characters long.
Error, password must contain at least one digit.
Please re-enter password: Jack790

You entered a valid password.


C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\120619\Debug\120619.exe (process 44788) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will ask the user for a password and verifies of it meets the criteria.

----PASSWORD VERIFIER PROGRAM----

Enter a password that meets the following criteria:
-Minimum of 6 characters in length.
-Contains at least one uppercase and one lowercase letter.
-Contains at least one digit.

->lolxD123

You entered a valid password.


C:\Users\kwokj\Desktop\CMPSC 121 files\source\repos\120619\Debug\120619.exe (process 96584) exited with code 0.
Press any key to close this window . . .
*/