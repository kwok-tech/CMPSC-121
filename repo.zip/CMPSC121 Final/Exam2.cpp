#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <fstream>
using namespace std;

struct Students {
	string firstName, lastName;
	int stuId;
	double exam1, exam2, exam3;
	double avg;
	char lGrade;
};
const int SIZE = 6;

void fileInitialize(ifstream& inFile, Students[]);
void calcAvg(Students[]);
void sort(Students[]);
void displaySort(Students[]);
void searchByLast(Students[]);
void fileDisplay(ofstream& outFile, Students[]);


int main() {
	// Program description
	cout << "This program will display an interactive menu.\n\n";
	// Declaring the variables: types and names
	int input;
	ofstream outFile;
	ifstream inFile;
	Students compClass[SIZE];
	// Variable initialization: getting the input from the user
	
	// open file for output
	outFile.open("result.txt", ios::app);
	if (outFile.fail())
	{
		cout << "Unable to open file for output\n";
		exit(1);
	}
	//menu
	cout << "Menu \n1. Enter the name of the file that contains students enrolled in the computer course."
		<< "\n2. Calculate and display the average and the letter grade for each student to the screen."
		<< "\n3. Sort data from lowest to highest average grade."
		<< "\n4. Display the sorted data to the screen."
		<< "\n5. Search for a student record by last name and display the student's full name, \"Exam Average\" and \"Letter Grade\" ."
		<< "\n6. Write the sorted data to the \"result.txt\" file, including ALL of the member variable values (input and calculated)."
		<< "\n7. Exit.\nInput: ";
	cin >> input;
	while (input != 7) {
		if (input == 1) {
			fileInitialize(inFile, compClass);
		}
		else if (input == 2) {
			calcAvg(compClass);
		}
		else if (input == 3) {
			sort(compClass);
		}
		else if (input == 4) {
			displaySort(compClass);
		}
		else if (input == 5) {
			searchByLast(compClass);
		}
		else if (input == 6) {
			fileDisplay(outFile, compClass);
		}
		else {
			cout << "Invaild Input\n";
		}
		cout << "Menu \n1. Enter the name of the file that contains students enrolled in the computer course."
			<< "\n2. Calculate and display the average and the letter grade for each student to the screen."
			<< "\n3. Sort data from lowest to highest average grade."
			<< "\n4. Display the sorted data to the screen."
			<< "\n5. Search for a student record by last name and display the student's full name, \"Exam Average\" and \"Letter Grade\" ."
			<< "\n6. Write the sorted data to the \"result.txt\" file, including ALL of the member variable values (input and calculated)."
			<< "\n7. Exit.\nInput: ";
		cin >> input;
	}
	// Display the results
	inFile.close();
	outFile.close();

	return 0;
}

void fileInitialize(ifstream& inFile, Students c[]) {
	string fileName;
	cout << "Enter the name of the file that contains students enrolled in the computer course. \nName: ";
	cin >> fileName;
	// open file for input
	inFile.open(fileName);
	if (inFile.fail())
	{
		cout << "Unable to open file for input\n";
		exit(2);
	}
	for (int i = 0; i < SIZE; i++) {
		inFile >> c[i].firstName >> c[i].lastName >> c[i].stuId >> c[i].exam1 >> c[i].exam2 >> c[i].exam3;
	}
	cout << "File opened.\n";
}

void calcAvg(Students c[]) {
	cout << "Name\t\tAverage\tLetterGrade\n";
	for (int i = 0; i < SIZE; i++) {
		c[i].avg = (c[i].exam1 + c[i].exam2 + c[i].exam3) / 3;
		if (c[i].avg > 90)
			c[i].lGrade = 'A';
		else if (c[i].avg > 80)
			c[i].lGrade = 'B';
		else if (c[i].avg > 70)
			c[i].lGrade = 'C';
		else if (c[i].avg > 60)
			c[i].lGrade = 'D';
		else
			c[i].lGrade = 'F';
		//display
		cout << fixed << setprecision(1) << c[i].firstName << " " << c[i].lastName << "\t" << c[i].avg << "\t" << c[i].lGrade <<endl;
	}
}

void sort(Students c[]) {
	Students min, temp;
	int i, j, moves, minind;
	moves = 0;
	for (i = 0; i < SIZE; i++)
	{
		min = c[i];
		minind = i;
		for (j = i + 1; j < SIZE; j++)
			if (c[j].avg < min.avg)
			{
				min = c[j];
				minind = j;
			}
		// perform the switch
		if (min.avg < c[i].avg)
		{
			temp = c[i];
			c[i] = min;
			c[minind] = temp;
			++moves;
		}
	}
	cout << '\n' << moves << " moves were made to sort this list\n";
}
void displaySort(Students c[]) {
	cout << "Name\t\tAverage\tLetterGrade\n";
	for (int i = 0; i < SIZE; ++i)
		cout << fixed << setprecision(1) << c[i].firstName << " " << c[i].lastName << "\t" << c[i].avg << "\t" << c[i].lGrade << endl;
}

void searchByLast(Students c[]) {
	string last;
	cout << "Last Name: ";
	cin >> last;
	for (int i = 0; i < SIZE; ++i) {
		if (last == c[i].lastName) {
			cout << fixed << setprecision(1) << c[i].firstName << " " << c[i].lastName << "\t" << c[i].avg << "\t" << c[i].lGrade << endl;
		}
	}
}

void fileDisplay(ofstream& outFile, Students c[]) {
	outFile << "Name\t\tStudent ID\tExam Grades\t\tAverage\tLetterGrade\n";
	for (int i = 0; i < SIZE; ++i)
		outFile << fixed << setprecision(1) << c[i].firstName << " " << c[i].lastName 
		<< "\t" << c[i].stuId
		<< "\t" << c[i].exam1
		<< " " << c[i].exam2
		<< " " << c[i].exam3
		<< "\t" << c[i].avg
		<< "\t" << c[i].lGrade
		<< endl;

}

/*
This program will display an interactive menu.

Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 1
Enter the name of the file that contains students enrolled in the computer course.
Name: studInfo.txt
Unable to open file for input

C:\Users\kwokj\source\repos\CMPSC121 Final\Debug\CMPSC121 Final.exe (process 83172) exited with code 2.
Press any key to close this window . . .
*/
/*
This program will display an interactive menu.

Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 9
Invaild Input
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 1
Enter the name of the file that contains students enrolled in the computer course.
Name: studInfo2.txt
File opened.
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 2
Name            Average LetterGrade
student one     73.3    C
student two     84.0    B
student three   84.7    B
student four    62.3    D
student five    90.7    A
student six     60.0    F
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 3

4 moves were made to sort this list
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 4
Name            Average LetterGrade
student six     60.0    F
student four    62.3    D
student one     73.3    C
student two     84.0    B
student three   84.7    B
student five    90.7    A
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 5
Last Name: two
student two     84.0    B
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 6
Menu
1. Enter the name of the file that contains students enrolled in the computer course.
2. Calculate and display the average and the letter grade for each student to the screen.
3. Sort data from lowest to highest average grade.
4. Display the sorted data to the screen.
5. Search for a student record by last name and display the student's full name, "Exam Average" and "Letter Grade" .
6. Write the sorted data to the "result.txt" file, including ALL of the member variable values (input and calculated).
7. Exit.
Input: 7

C:\Users\kwokj\source\repos\CMPSC121 Final\Debug\CMPSC121 Final.exe (process 83720) exited with code 0.
Press any key to close this window . . .
*/