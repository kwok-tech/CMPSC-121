/*********************************************************
* file name: Quiz6.cpp
* programmer name: Jack Kwok
* date created: 11/17/19
* date of last revision: 11/17/19
* details of the revision: none
* short description:  This program will calculate display house and fuel cost
**********************************************************/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and display\n"
		<< "display house and fuel cost\n\n";
	// Declaring the variables: types and names
	ifstream inFile;
	ofstream outFile;
	double houseInfo[10][5];
	// opening files
	inFile.open("houseInfo.txt");
	if (inFile.fail())
	{
		cout << "Unable to open file for input\n";
		exit(1);
	}
	outFile.open("houseInfo.txt", ios::app);
	if (outFile.fail())
	{
		cout << "Unable to open file for output\n";
		exit(1);
	}
	outFile << endl;
    // read all lines  -- like cin
	for (int i = 0; i < 10; i++) {
		inFile >> houseInfo[i][0] >> houseInfo[i][1] >> houseInfo[i][2] >> houseInfo[i][3];
		//Calculations
		houseInfo[i][4] = houseInfo[i][2] + 5 * houseInfo[i][3] + 5 * (houseInfo[i][2] * houseInfo[i][1]);
	}
	inFile.close();
	cout << "In writeFile\n";
	// write data to file  -- like cout (need a loop)
	for (int i = 0; i < 10; i++) {
		outFile << fixed << setprecision(2);
		outFile << "\nID: " << houseInfo[i][0] << "\nTotal House Cost: " << houseInfo[i][4];
	}
	
	outFile.close();
	return 0;
}