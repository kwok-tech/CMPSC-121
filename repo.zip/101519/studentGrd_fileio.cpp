#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
	//vars
	const int NUMGRADES = 3;
	ifstream inFile;
	string fileName, stuName;
	int stuCount = 0;
	float grade, total=0, average;
	char letterGrade;

	//open file
	cout << "Enter name of input file: ";
	cin >> fileName;
	inFile.open(fileName);
	if (inFile.fail()) {
		cout << "Can't find file";
		exit(1);
	}
	//process data for multiple students - 3 grades for each
	while (inFile >> stuName) {
		stuCount++;
		
		for (int i = 1; i < NUMGRADES; i++) {
			inFile >> grade;
			if (grade >= 0 && grade <= 100) {
				total += grade;
			}
		}
		//calculate student average
		average = total / NUMGRADES;
		//determine letter grade
		if (average <= 90)
			letterGrade = 'A';
		else if (average <= 80)
			letterGrade = 'B';
		else if (average <= 70)
			letterGrade = 'C';
		else if (average <= 60)
			letterGrade = 'D';
		else
			letterGrade = 'F';
		//display the result
		cout << "Student Name: " << stuName;
		cout << "\nAverage: " << average;
		cout << "\nLetterGrade" << letterGrade;
		total = 0;
	}

	system("pause");
	return 0;
}