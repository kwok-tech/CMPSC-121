#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
using namespace std;

struct StuInfo
{
	string lastName;
	double exam1, exam2, exam3;
	double overallAvg;
	char letterGrade;
};

void writeStuInfo(ofstream& outFile, StuInfo stu);
void readStuInfo(ifstream& inFile, StuInfo& stu);
double avgGrade(double ex1, double ex2, double ex3);
char getLetterGrade(double avg);
/*
First read date in from a file into StuInfo structure
Then calc average and assign
Then calc letter grade and assign
Then append results to the same file
*/

int main()
{
	ofstream outFile;
	ifstream inFile;
	StuInfo stu;
	const int NUM_STU = 5;
	// open file for input
	inFile.open("gradeInfo.txt");
	if (inFile.fail())
	{
		cout << "Unable to open file for input\n";
		exit(2);
	}
	// open file for output
	outFile.open("gradeInfo.txt",ios::app);
	if (outFile.fail())
	{
		cout << "Unable to open file for output\n";
		exit(1);
	}

	// loop to process data
	while (inFile >> stu.lastName && stu.lastName != "zzzzz")
	{
		// read data from file
		readStuInfo(inFile, stu);
		// calculations
		stu.overallAvg = avgGrade(stu.exam1, stu.exam2, stu.exam3);
		stu.letterGrade = getLetterGrade(stu.overallAvg);
		// write data to the file
		outFile << fixed << setprecision(2);
		writeStuInfo(outFile, stu);
	}
	inFile.close();
	outFile.close();

	return 0;
}

void writeStuInfo(ofstream& outFile, StuInfo stu)
{
	// write one student record
	outFile << setw(10) << stu.lastName << setw(8) << stu.overallAvg
		<<setw(5) << stu.letterGrade << endl;
}

void readStuInfo(ifstream& inFile, StuInfo& stu)
{
	// read in one student record
	inFile >> stu.exam1 >> stu.exam2 >> stu.exam3;
		
	
}

double avgGrade(double ex1, double ex2, double ex3)
{
	return (ex1 + ex2 + ex3) / 3.0;
}
char getLetterGrade(double avg)
{
	if (avg >= 90)
		return 'A';
	else if (avg >= 80)
		return 'B';
	else if (avg >= 70)
		return 'C';
	else if (avg >= 60)
		return 'D';
	else
		return 'F';
}