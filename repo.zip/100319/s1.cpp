#include <iostream>
using namespace std;

int main()
{
	float grade, total;
	int count = 0;
	grade = 0;
	total = 0;
	
	for (int count = 1; count <= 3; count++)
	{
		cout << "Enter a grade " << count << ": ";
		cin >> grade;
		if (grade < 0 || grade > 100)
		{
			count--;
			continue;
		}
		
		total += grade;
	}
	cout << count << endl;
	cout << "\nThe total of the grades is " << total << endl;

	system("pause");
	return 0;
}
