#include <iostream>
using namespace std;

int main() {
	int grade;
	do
		cin >> grade;
	while (grade < 0 || grade >100);
	cout << grade;
	return 0;
}