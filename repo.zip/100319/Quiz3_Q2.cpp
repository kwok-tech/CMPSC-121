/*********************************************************
* file name: Quiz3_Q2.cpp
* programmer name: *** Jack Kwok ***
* date created: 9/27/18
* date of last revision: 10/3/19
* details of the revision: for quiz
* short description:  Calculating the total shipping charges
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// Program description
	cout << "This program will calculate and display" << endl
		<< "the total shipping charges based on the weight\n"
		<< "and the shipping distance.\n\n";

	// Declaring the variables: types and names
	double packageWeight, distance, rate, shippingCharge;
	// **** Declare a constant for the distance multiple of 500  ****
	const int DISTMULTIPLE = 500;
	// Variable initialization: getting the input from the user
	cout << "Enter the weight of the package in kg: ";
	cin >> packageWeight;
	cout << "Enter the distance shipped in miles: ";
	cin >> distance;

	// Calculations
	// **** Use a selection statement to determine the 
	// **** rate for each 500 miles shipped based on the package weight
	if (packageWeight < 2)
		rate = 1.1;
	else if (packageWeight >= 2 && packageWeight < 6)
		rate = 2.2;
	else if (packageWeight >= 6 && packageWeight < 10)
		rate = 3.7;
	else if (packageWeight >= 10 && packageWeight <= 20)
		rate = 4.8;
	else if (packageWeight > 20) {
		cout << "not accepted";
		exit(0);
	}
	shippingCharge = distance / DISTMULTIPLE * rate;
	
	// Display the results
	// *** Add output stream manipulator as needed for number formatting 
	cout << fixed << setprecision(2);
	cout << "A package which weighs " << packageWeight << " kg will cost $"
		<< rate << " per 500 miles shipped." << endl;
	cout << "The cost to ship this package " << distance << " miles is $"
		<< shippingCharge << endl;

	system("pause");
	return 0;
}

/* Output test 1
This program will calculate and display
the total shipping charges based on the weight
and the shipping distance.

Enter the weight of the package in kg: 6.5
Enter the distance shipped in miles: 1000.0
A package which weighs 6.50 kg will cost $3.70 per 500 miles shipped.
The cost to ship this package 1000.00 miles is $7.40
Press any key to continue . . .
*/