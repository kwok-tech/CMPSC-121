/*********************************************************
* file name: Kwok_4_7.cpp
* programmer name: Jack Kwok
* date created: 9/24/19
* date of last revision: 9/24/19
* details of the revision: none
* short description: This program will display the number of minutes, hours, or days based on the number of seconds the user inputs
**********************************************************/
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and display" << endl
		<< "the number of minutes, hours, or days based on the number of seconds the user inputs\n\n";
	// Declaring the variables: types and names
	int numOfSecs;
	double numOfMins, numOfHours, numOfDays;
	// Variable initialization: getting the input from the user
	cout << "Number of seconds: ";
	cin >> numOfSecs;
	// Calculations
	numOfMins = numOfSecs / 60.0;
	numOfHours = numOfSecs / 3600.0;
	numOfDays = numOfSecs / 86400.0;
	// Display the results
	if (numOfSecs >= 86400)
		cout << "Number of Days: " << numOfDays << endl;
	else if (numOfSecs >= 3600)
		cout << "Number of Hours: " << numOfHours << endl;
	else if (numOfSecs >= 60)
		cout << "Number of Minutes: " << numOfMins << endl;
	
	return 0;
}

/*
This program will calculate and display
the number of minutes, hours, or days based on the number of seconds the user inputs

Number of seconds: 67
Number of Minutes: 1.11667
*/

/*
This program will calculate and display
the number of minutes, hours, or days based on the number of seconds the user inputs

Number of seconds: 742836
Number of Days: 8.59764
*/

/*
This program will calculate and display
the number of minutes, hours, or days based on the number of seconds the user inputs

Number of seconds: 5011
Number of Hours: 1.39194
*/