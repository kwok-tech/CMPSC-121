#include <iostream>
using namespace std;

int main() {
	int month, day;
	cout << "Enter a month as a number: ";
	cin >> month;
	cout << "Enter a day: ";
		cin >> day;

	switch (month) {
	case 1 :case 2: case 3:
		if (month == 3 && day >= 21)
			cout << "Season: Spring";
		else
			cout << "Season: Winter";
		break;
	case 4: case 5: case 6:
		if (month == 6 && day >= 21)
			cout << "Season: Summer";
		else
			cout << "Season: Spring";
		break;
	case 7: case 8: case 9:
		if (month == 9 && day >= 21)
			cout << "Season: Fall";
		else
			cout << "Season: Summer";
		break;
	case 10: case 11: case 12:
		if (month == 12 && day >= 21)
			cout << "Season: Winter";
		else
			cout << "Season: Fall";
		break;
	default:
		cout << "invalid month";
	}
}