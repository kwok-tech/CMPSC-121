#include <iostream>  
using namespace std;

int  main()
{
	char shipCode;

	cout << "Enter a code for the ship's class: ";
	cin >> shipCode;

	cout << "\n\nShip's Class: ";

		switch (shipCode)
		{
		case 'B': case 'b':
			cout << "Battleship\n";
			break;
		case 'C': case 'c':
			cout << "Cruiser";
			break;
		case 'D': case 'd':
			cout << "Destroyer\n";
			break;
		case 'F': case 'f':
			cout << "Frigate\n";
			break;
		default:
			cout << "Unknown ship class\n";
		}

	return 0;
}

