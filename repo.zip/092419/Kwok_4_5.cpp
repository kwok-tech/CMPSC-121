/*********************************************************
* file name: Kwok_4_5.cpp
* programmer name: Jack Kwok
* date created: 9/24/19
* date of last revision: 9/24/19
* details of the revision: none
* short description:  Calculates and displays a person's BMI and determine whether the user is overweight, underweight, or an optimal weight
**********************************************************/
#include <iostream>
#include <cmath>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and display" <<endl
		<< "the user's BMI and determine whether the user is overweight, underweight, or an optimal weight\n\n";
	// Declaring the variables: types and names
	double weight, height, bmi;
	// Variable initialization: getting the input from the user
	cout << "what is your weight in pounds? ";
	cin >> weight;
	cout << "what is your height in inches? ";
	cin >> height;
	// Calculations
	bmi = weight * 701 / pow(height, 2);
	// Display the results
	cout << "Your BMI is " << bmi << endl;
	if (bmi >= 18.5 && bmi <= 25)
		cout << "Your weight is optimal.";
	else if (bmi < 18.5)
		cout << "You are underweight.";
	else
		cout << "You are overweight.";

	return 0;
}

/*
This program will calculateand display
the user's BMI and determine whether the user is overweight, underweight, or an optimal weight

what is your weight in pounds ? 160
what is your height in inches ? 72
Your BMI is 21.6358
Your weight is optimal.
*/

/*
This program will calculate and display
the user's BMI and determine whether the user is overweight, underweight, or an optimal weight

what is your weight in pounds? 300
what is your height in inches? 80
Your BMI is 32.8594
You are overweight.
*/

/*
This program will calculate and display
the user's BMI and determine whether the user is overweight, underweight, or an optimal weight

what is your weight in pounds? 130
what is your height in inches? 80
Your BMI is 14.2391
You are underweight.
*/