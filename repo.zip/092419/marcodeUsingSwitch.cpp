#include <iostream>  
using namespace std;

int  main()
{
	char marCode;

	cout << "Enter a marital code: ";
	cin >> marCode;

	switch (marCode)
	{
	case 'M' : case 'm' :
		cout << "\nIndividual is married.";
		break;
	case 'S': case 's':
		cout << "\nIndividual is single.";
		break;
	case 'D': case 'd':
		cout << "\nIndividual is divorced.";
		break;
	case 'W' : case 'w':
		cout << "\nIndividual is widowed.";
		break;
	default:
		cout << "\nAn invalid code was entered.";
		break;
	}

	return 0;
}

