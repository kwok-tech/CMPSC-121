/*********************************************************
* file name: q2.cpp
* programmer name: Jack Kwok
* date created: 10/17/19
* date of last revision: 10/17/19
* details of the revision: none
* short description: This program will calculate and display each employee�s weekly pay and the accumulated total pay for the company.
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and display" << endl
		<< "each employee's weekly pay and the accumulated total pay for the company.\n\n";
	//Declaring the variables: types and names
	int employees;
	double hours, rate, pay, ttlPay =0;
	
	// Variable initialization : getting the input from the user
	cout << "Enter number of employees: ";
	cin >> employees;
	cout << fixed << setprecision(2);
	for (int i = 0; i < employees; i++) {
		cout << "\nHours: ";
		cin >> hours;
		cout << "Rate (in dollars):  ";
		cin >> rate;
		// Calculations
		pay = hours * rate;
		cout << "Pay is $" << pay << endl;
		ttlPay += pay;
	}
	
	// Display the results
	cout << "\nAll employees processed."
		<< "\nTotal payroll is $" << ttlPay;
	return 0;
}
/*
This program will calculate and display
each employee's weekly pay and the accumulated total pay for the company.

Enter number of employees: 3

Hours: 5
Rate (in dollars):  4.00
Pay is $20.00

Hours: 6
Rate (in dollars):  5.00
Pay is $30.00

Hours: 1.5
Rate (in dollars):  10.00
Pay is $15.00

All employees processed.
Total payroll is $65.00
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 29924) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
each employee's weekly pay and the accumulated total pay for the company.

Enter number of employees: 7

Hours: 3
Rate (in dollars):  4.00
Pay is $12.00

Hours: 8
Rate (in dollars):  10.00
Pay is $80.00

Hours: 6
Rate (in dollars):  3.50
Pay is $21.00

Hours: 18
Rate (in dollars):  19.50
Pay is $351.00

Hours: 6
Rate (in dollars):  4.50
Pay is $27.00

Hours: 4.5
Rate (in dollars):  80
Pay is $360.00

Hours: 5.8
Rate (in dollars):  6.70
Pay is $38.86

All employees processed.
Total payroll is $889.86
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 102424) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
each employee's weekly pay and the accumulated total pay for the company.

Enter number of employees: 2

Hours: 7
Rate (in dollars):  20.68
Pay is $144.76

Hours: 1.5
Rate (in dollars):  50
Pay is $75.00

All employees processed.
Total payroll is $219.76
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 81012) exited with code 0.
Press any key to close this window . . .

*/