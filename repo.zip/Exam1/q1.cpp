/*********************************************************
* file name: q1.cpp
* programmer name: Jack Kwok
* date created: 10/17/19
* date of last revision: 10/17/19
* details of the revision: none
* short description: This program will calculate and display the conversion from ounces to grams, pounds, or kilograms, based on the user input
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	// Program description
	cout << "This program will calculate and display" << endl
		<< "the conversion from ounces to grams, pounds, or kilograms, based on the user input\n\n";
	//Declaring the variables: types and names
	const double GRAMCONV = 28.349527, LBSCONV = 16, KGCONV = 1000;
	double value, nVal;
	char outUnits;

	// Variable initialization : getting the input from the user
	cout << "Please enter the weight in ounce and the"
		<< "\noutUnit symbol according to the following"
		<< "\nchart:" 
		<< "\nG or g for grams"
		<< "\nP or p for pounds"
		<< "\nK or k for kilograms" << endl;
	cin >> value >> outUnits;

	// Calculations and Display the results
	cout << fixed << setprecision(3);
	switch (outUnits) {
	case 'G': case 'g':
		nVal = value * GRAMCONV;
		cout << value << " ounces is equal to " << nVal << " grams.";
		break;
	case 'P': case 'p':
		nVal = value * LBSCONV;
		cout << value << " ounces is equal to " << nVal << " lbs.";
		break;
	case 'K': case 'k':
		nVal = value * KGCONV;
		cout << value << " ounces is equal to " << nVal << " Kg.";
		break;
	default:
		cout << "Invalid Units!!";
		break;
	}
	return 0;
}
/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart:
G or g for grams
P or p for pounds
K or k for kilograms
100.00 g
100.000 ounces is equal to 2834.953 grams.
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 41596) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart:
G or g for grams
P or p for pounds
K or k for kilograms
891 G
891.000 ounces is equal to 25259.429 grams.
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 90504) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart:
G or g for grams
P or p for pounds
K or k for kilograms
450 p
450.000 ounces is equal to 7200.000 lbs.
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 62120) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart:
G or g for grams
P or p for pounds
K or k for kilograms
365 P
365.000 ounces is equal to 5840.000 lbs.
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 99696) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart:
G or g for grams
P or p for pounds
K or k for kilograms
679 k
679.000 ounces is equal to 679000.000 Kg.
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 3568) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart:
G or g for grams
P or p for pounds
K or k for kilograms
900 K
900.000 ounces is equal to 900000.000 Kg.
C:\Users\kwokj\source\repos\Exam1\Debug\Exam1.exe (process 40372) exited with code 0.
Press any key to close this window . . .

*/

/*
This program will calculate and display
the conversion from ounces to grams, pounds, or kilograms, based on the user input

Please enter the weight in ounce and the
outUnit symbol according to the following
chart :
G or g for grams
P or p for pounds
K or k for kilograms
456 h
Invalid Units!!
C : \Users\kwokj\source\repos\Exam1\Debug\Exam1.exe(process 28032) exited with code 0.
Press any key to close this window . . .

*/