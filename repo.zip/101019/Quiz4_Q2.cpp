/*********************************************************
* file name: Quiz4_Q2.cpp
* programmer name: Jack Kwok
* date created: 10/10/18
* date of last revision: 10/10/18
* details of the revision: none
* short description:  Calculate a product of 10 valid numbers
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// Program description
	cout << "This program will calculate and display" << endl
		<< "the product of 10 valid numbers entered by the user.\n\n";

	// Declaring the variables: types and names
	float number;		// user input  
	float product;		// calculation and output 
	int count;			// loop control variable

	// Variable initialization: getting the input from the user
	// *** Initialize any variables that are needed for the loop
	product = 1;
	

	// *** Use a loop to read in 10 valid numbers 
	for (count =1;count<=10;count++)
	{
		// Prompt and read in the number
		cout << "Enter a value #" << count << ": ";
		cin >> number;
		// *** Inside the loop: ignore all negative and zero values entered
		if (number > 0)
			// Calculations
		// *** Accumulate your product
			product *= number;
		else
			count--;


	}

	// Display the results
	// *** Use appropriate statement to display using decimal place accuracy
	cout << fixed << setprecision(2);
	cout << "The product of ten numbers is " << product << endl;

	system("pause");
	return 0;
}

/*  Output run
This program will calculate and display
the product of 10 valid numbers entered by the user.

Enter a value #1: -6
Enter a value #1: 5.0
Enter a value #2: 0
Enter a value #2: 1.5
Enter a value #3: 10
Enter a value #4: -3.1
Enter a value #4: 10
Enter a value #5: 2.5
Enter a value #6: 5
Enter a value #7: -2.3
Enter a value #7: 7.5
Enter a value #8: 2.0
Enter a value #9: 0
Enter a value #9: 1.0
Enter a value #10: 4
The product of ten numbers is 562500.00
Press any key to continue . . .
*/