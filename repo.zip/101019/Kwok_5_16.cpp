/*********************************************************
* file name: Kwok_5_16.cpp
* programmer name: Jack Kwok
* date created: 10/11/19
* date of last revision: 10/11/19
* details of the revision: none
* short description:  Calculating the balance of a savings
   account at the end of a period of time
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// Program description
	cout << "This program will calculate and display\n"
		<< "the balance of a savings account at the end of a period of time\n";

	// Declaring the variables: types and names
	int monthsPassed;
	double annualInterestRate, startingBalance, accountBalance,
		monthlyDeposits, depositsTotal = 0, monthlyWithdrawals, withdrawalsTotal = 0, monthlyInterest=0;
		
	// Variable initialization: getting the input from the user
	cout << "Annual Interest Rate: ";
	cin >> annualInterestRate;
	cout << "Staring Balance: $";
	cin >> startingBalance;
	accountBalance = startingBalance;
	cout << "Number of months that have passed since Account was established: ";
	cin >> monthsPassed;
	// Calculations
	for (int i = 0; i < monthsPassed; i++) {
		//Deposits
		cout << "Deposit Amount for Month " << i + 1 << ": $";
		cin >> monthlyDeposits;
		if (monthlyDeposits!=0)
			depositsTotal += 1;
		accountBalance += monthlyDeposits;
		//Withdrawals
		cout << "Withdrawal Amount for Month " << i + 1 << ": $";
		cin >> monthlyWithdrawals;
		while (monthlyWithdrawals < 0) {
			cout << "Enter a positive Number: $";
			cin >> monthlyWithdrawals;
		}
		if (monthlyWithdrawals != 0)
			withdrawalsTotal += 1;
		accountBalance -= monthlyWithdrawals;
		//account
		monthlyInterest = annualInterestRate  / 12;
		accountBalance += monthlyInterest * accountBalance;
		if (accountBalance < 0)
			cout << "Account closed.";
	}
	cout << fixed << setprecision(2) << "\nEnding Balance: " << accountBalance
		<< "\nTotal Amount of Deposits : " << depositsTotal
		<< "\nTotal Amount of Withdrawals" << withdrawalsTotal
		<< "\nTotal Interest Earned: " << monthlyInterest * monthsPassed;
	return 0;
}

/*
This program will calculateand display
the balance of a savings account at the end of a period of time
Annual Interest Rate : 1.9
Staring Balance : $100
Number of months that have passed since Account was established : 3
Deposit Amount for Month 1 : $10
Withdrawal Amount for Month 1 : $2.9
Deposit Amount for Month 2 : $100
Withdrawal Amount for Month 2 : $2.10
Deposit Amount for Month 3 : $100.90
Withdrawal Amount for Month 3 : $70.90

Ending Balance : 332.56
Total Amount of Deposits : 3.00
Total Amount of Withdrawals3.00
Total Interest Earned : 0.47
*/

/*
This program will calculate and display
the balance of a savings account at the end of a period of time
Annual Interest Rate: 2.9
Staring Balance: $16
Number of months that have passed since Account was established: 2
Deposit Amount for Month 1: $100.89
Withdrawal Amount for Month 1: $-2
Enter a positive Number: $10.9
Deposit Amount for Month 2: $20
Withdrawal Amount for Month 2: $-7
Enter a positive Number: $-9
Enter a positive Number: $1000
Account closed.
Ending Balance: -1053.42
Total Amount of Deposits : 2.00
Total Amount of Withdrawals2.00
Total Interest Earned: 0.48
*/