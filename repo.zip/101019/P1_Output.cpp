#include <fstream>
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	string fileName;
	ofstream outFile;
	double price;
	char ch;
	ofstream outFile;
	ifstream inFile;
	cout << "File Name: ";
	cin >> fileName;
	outFile.open(fileName.c_str());
	if (outFile.fail()) {
		cout << "Unable to open file for output.\n";
		exit(1);
	}

	// set the output file stream formats
	outFile << setiosflags(ios::fixed) << setprecision(2);
	// send data to the file
	outFile << "Batteries " << 39.95 << endl
		<< "Bulbs " << 3.22 << endl
		<< "Fuses " << 1.00;
	outFile.close();
	inFile.open(fileName);
	if (inFile.fail()) {
		cout << "Unable to open file for input. \n";
		exit(2);
	}
	string description;
	float price;
	char ch;
	while ((ch = inFile.peek()) != EOF) {
		inFile >> description >> price;
		cout << description << endl;
	}
	inFile.close();


	return 0;
}