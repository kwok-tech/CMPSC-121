/*********************************************************
* file name: Kwok_5_10.cpp
* programmer name: Jack Kwok
* date created: 10/10/19
* date of last revision: 10/10/19
* details of the revision: none
* short description:  Calculating the average rainfall over a period of years.
**********************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	// Program description
	cout << "This program will calculate and display\n"
		<< "the average rainfall over a period of years.\n";

	// Declaring the variables: types and names
	int years, totalMonths;
	const int MONTHS = 12;
	double rainfall, totalRainfall, avgRainfall;

	// Variable initialization: getting the input from the user
	cout << "Number Of Years: ";
	cin >> years;
	while (years < 1) {
		cout << "Enter a number greater than 0: ";
		cin >> years;
	}
	// Calculations
	totalRainfall = 0;
	totalMonths = years * MONTHS;
	for (int i = 0; i < years; i++) {
		for (int j = 0; j < MONTHS; j++) {
			cout << "Inches of Rainfall in Month " << j + 1 << ": ";
			cin >> rainfall;
			while (rainfall < 0) {
				cout << "Enter a postive number: ";
				cin >> rainfall;
			}
			totalRainfall += rainfall;
		}
	}
	avgRainfall = totalRainfall / totalMonths;
	//Display to User
	cout << fixed << setprecision(2);
	cout << "\nNumber of Months: " << totalMonths
		<< "\nTotal Inches of rainfall: " << totalRainfall
		<< "\nAverage Rainfall per Month: " << avgRainfall
		<< endl;

	
	return 0;
}

/*
This program will calculate and display
the average rainfall over a period of years.
Number Of Years: -9
Enter a number greater than 0: 2
Inches of Rainfall in Month 1: 2.3
Inches of Rainfall in Month 2: 2.4
Inches of Rainfall in Month 3: 2.3
Inches of Rainfall in Month 4: 12
Inches of Rainfall in Month 5: 77.1
Inches of Rainfall in Month 6: 3
Inches of Rainfall in Month 7: 1.2
Inches of Rainfall in Month 8: 7.7
Inches of Rainfall in Month 9: 3.2
Inches of Rainfall in Month 10: 1.8
Inches of Rainfall in Month 11: 12
Inches of Rainfall in Month 12: 12
Inches of Rainfall in Month 1: 1.2
Inches of Rainfall in Month 2: 7.8
Inches of Rainfall in Month 3: 9.3
Inches of Rainfall in Month 4: 4.6
Inches of Rainfall in Month 5: 8.99
Inches of Rainfall in Month 6: 2.75
Inches of Rainfall in Month 7: 1.83
Inches of Rainfall in Month 8: 1.4
Inches of Rainfall in Month 9: -8
Enter a postive number: 0.4
Inches of Rainfall in Month 10: 0
Inches of Rainfall in Month 11: -3
Enter a postive number: 8.9
Inches of Rainfall in Month 12: 9

Number of Months: 24
Total Inches of rainfall: 193.17
Average Rainfall per Month: 8.05
*/

/*
This program will calculate and display
the average rainfall over a period of years.
Number Of Years: 1
Inches of Rainfall in Month 1: 2
Inches of Rainfall in Month 2: 4
Inches of Rainfall in Month 3:
3
Inches of Rainfall in Month 4: 4
Inches of Rainfall in Month 5: 7
Inches of Rainfall in Month 6:
3
Inches of Rainfall in Month 7: 4
Inches of Rainfall in Month 8: 6
Inches of Rainfall in Month 9: 3
Inches of Rainfall in Month 10: 5
Inches of Rainfall in Month 11: 3
Inches of Rainfall in Month 12: 5

Number of Months: 12
Total Inches of rainfall: 49.00
Average Rainfall per Month: 4.08
*/