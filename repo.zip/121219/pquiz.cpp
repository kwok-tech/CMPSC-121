#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

struct GradeInfo {
	int quiz1, quiz2;
	float midterm, final;
	float grade;
	char lGrade;
};

void readData(ifstream& inFile, GradeInfo grades[]);
void writeData(ofstream& outFile, GradeInfo grades[]);
void calcGrade(GradeInfo grades[]);
void getLGrade(GradeInfo grades[]);

const int SIZE = 5;

int main() {
	//Vars
	ifstream inFile;
	ofstream outFile;
	GradeInfo grades[SIZE];
	
	//Open Files
	inFile.open("GradesIn.txt");
	if (inFile.fail) {
		cout << "ERROR, File not found.";
		exit(1);
	}
	outFile.open("GradesOut.txt");
	if (outFile.fail) {
		cout << "ERROR, File not found.";
		exit(2);
	}
	//Var Initialization
	readData(inFile, grades);
	//Calulations
	calcGrade(grades);
	getLGrade(grades);
	//Display/ Write Results
	writeData(outFile, grades);

	inFile.close();
	outFile.close();
	return 0;
}

void readData(ifstream& inFile, GradeInfo grades[]) {
	string name;
	for (int i = 0; i < SIZE; i++) {
		inFile >> name >> grades[i].quiz1 >> grades[i].quiz2 >> grades[i].midterm >> grades[i].final;
	}
}

void writeData(ofstream& outFile, GradeInfo grades[]) {
	for (int i = 0; i < SIZE; i++) {
		outFile << "\n" << grades[i].grade << "\t" << grades[i].lGrade;
	}
}

void calcGrade(GradeInfo grades[]) {
	for (int i = 0; i < SIZE; i++) {
		grades[i].grade = (((grades[i].quiz1 * 5 + grades[i].quiz2 * 5)*.25) + (grades[i].midterm * .25) + (grades[i].final * .50)) / 4;
	}
}

void getLGrade(GradeInfo grades[]) {
	for (int i = 0; i < SIZE; i++) {
		if (grades[i].grade > 92) {
			grades[i].lGrade = 'A';
		} else if (grades[i].grade > 83) {
			grades[i].lGrade = 'B';
		} else if (grades[i].grade > 73) {
			grades[i].lGrade = 'C';
		}
	}
}